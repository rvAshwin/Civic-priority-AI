"""Compare severity classifiers on one fixed, stratified holdout split.
Run: python model_benchmark.py
This is an evaluation utility; it does not manipulate labels or guarantee high scores.
"""
from pathlib import Path
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, HistGradientBoostingClassifier, RandomForestRegressor
from sklearn.dummy import DummyClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, balanced_accuracy_score, f1_score, classification_report
from sklearn.preprocessing import OrdinalEncoder
from sklearn.ensemble import HistGradientBoostingClassifier

BASE=Path(__file__).parent
inc=pd.read_csv(BASE/'data'/'incidents.csv')
loc=pd.read_csv(BASE/'data'/'locations.csv')
df=inc.merge(loc,on='location_id',how='left')
t=pd.to_datetime(df['timestamp'],errors='coerce')
df['report_hour']=t.dt.hour
df['report_month']=t.dt.month
cat=['incident_type','reported_by','zone','road_type','road_condition','pedestrian_activity']
num=['population_density_per_km2','near_school','near_hospital','report_hour','report_month']
features=cat+num
df=df.dropna(subset=['severity']).copy()
X=df[features]; y=df['severity'].astype(str).str.strip()
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.25,random_state=42,stratify=y)
pre=ColumnTransformer([
 ('cat',Pipeline([('impute',SimpleImputer(strategy='most_frequent')),('onehot',OneHotEncoder(handle_unknown='ignore'))]),cat),
 ('num',Pipeline([('impute',SimpleImputer(strategy='median'))]),num)
])
models={
 'Most-frequent baseline':DummyClassifier(strategy='most_frequent'),
 'Random Forest':RandomForestClassifier(n_estimators=400,min_samples_leaf=2,class_weight='balanced',random_state=42,n_jobs=-1),
 'Extra Trees':ExtraTreesClassifier(n_estimators=400,min_samples_leaf=2,class_weight='balanced',random_state=42,n_jobs=-1),
}
print(f'Rows: {len(df)} | Train: {len(Xtr)} | Test: {len(Xte)} | Split: stratified 75/25, seed=42')
print('\nScores on the SAME held-out test rows (higher is better; not guaranteed to be high):')
results=[]
for name,clf in models.items():
 pipe=Pipeline([('prep',pre),('model',clf)])
 pipe.fit(Xtr,ytr); pred=pipe.predict(Xte)
 row=(name,accuracy_score(yte,pred),balanced_accuracy_score(yte,pred),f1_score(yte,pred,average='macro',zero_division=0))
 results.append(row)
 print(f'{row[0]:24s} accuracy={row[1]:.3f} | balanced_accuracy={row[2]:.3f} | macro_F1={row[3]:.3f}')
print('\nDetailed report for the best macro-F1 model (on this one split):')
best=max(results,key=lambda r:r[3])[0]
clf=models[best]; pipe=Pipeline([('prep',pre),('model',clf)]); pipe.fit(Xtr,ytr)
print('Selected:',best)
print(classification_report(yte,pipe.predict(Xte),zero_division=0))
print('Note: this is one holdout split, not proof of generalisation to a real city.')
