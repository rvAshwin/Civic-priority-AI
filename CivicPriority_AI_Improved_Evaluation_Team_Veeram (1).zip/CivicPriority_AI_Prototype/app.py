import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path

st.set_page_config(page_title="CivicPriority AI | Team Veeram", page_icon="🏙️", layout="wide")
BASE = Path(__file__).parent
DATA = BASE / "data"

@st.cache_data
def load_data():
    locations = pd.read_csv(DATA / "locations.csv")
    incidents = pd.read_csv(DATA / "incidents.csv")
    complaints = pd.read_csv(DATA / "public_complaints.csv")
    incidents["injuries"] = pd.to_numeric(incidents["injuries"], errors="coerce").fillna(0)
    incidents["resolved"] = pd.to_numeric(incidents["resolved"], errors="coerce").fillna(0)
    complaints["priority_reported"] = complaints["priority_reported"].fillna("Unknown")
    return locations, incidents, complaints

def norm(series):
    x = pd.to_numeric(series, errors="coerce").fillna(0).astype(float)
    if len(x) == 0 or x.max() == x.min():
        return pd.Series(0.0, index=x.index)
    return (x - x.min()) / (x.max() - x.min())


locations, incidents, complaints = load_data()

# Train a real supervised ML model to predict incident severity.
# Only features plausibly available when an incident is reported are used.
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report, confusion_matrix

@st.cache_resource
def train_severity_model(incidents, locations):
    model_data = incidents.merge(locations, on="location_id", how="left")
    times = pd.to_datetime(model_data["timestamp"], errors="coerce")
    model_data["report_hour"] = times.dt.hour
    model_data["report_month"] = times.dt.month

    categorical = ["incident_type", "reported_by", "zone", "road_type",
                   "road_condition", "pedestrian_activity"]
    numeric = ["population_density_per_km2", "near_school", "near_hospital",
               "report_hour", "report_month"]
    features = categorical + numeric
    model_data = model_data.dropna(subset=["severity"]).copy()
    X = model_data[features]
    y = model_data["severity"].astype(str).str.strip()

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )
    prep = ColumnTransformer([
        ("cat", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore"))
        ]), categorical),
        ("num", Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scale", StandardScaler())
        ]), numeric)
    ])
    model = Pipeline([
        ("prep", prep),
        ("classifier", RandomForestClassifier(
            n_estimators=250, min_samples_leaf=2, class_weight="balanced",
            random_state=42, n_jobs=-1
        ))
    ])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, pred)
    macro_f1 = f1_score(y_test, pred, average="macro")
    report = classification_report(y_test, pred, output_dict=True, zero_division=0)
    matrix = confusion_matrix(y_test, pred, labels=model.named_steps["classifier"].classes_)
    # Predict each incident's High/Critical probability for a transparent location-level signal.
    all_X = model_data[features]
    probabilities = model.predict_proba(all_X)
    classes = list(model.named_steps["classifier"].classes_)
    risk_cols = [i for i, label in enumerate(classes) if label.lower() in ("high", "critical")]
    model_data["predicted_high_critical_risk"] = probabilities[:, risk_cols].sum(axis=1) if risk_cols else 0.0
    risk_by_location = model_data.groupby("location_id")["predicted_high_critical_risk"].mean().rename("ml_severity_risk").reset_index()
    return model, accuracy, macro_f1, report, matrix, classes, risk_by_location, len(X_train), len(X_test)

severity_model, model_accuracy, model_macro_f1, model_report, model_matrix, model_classes, ml_risk, train_rows, test_rows = train_severity_model(incidents, locations)

inc = incidents.groupby("location_id").agg(
    incident_count=("incident_id", "count"),
    high_critical=("severity", lambda s: s.astype(str).str.strip().str.lower().isin(["high", "critical"]).sum()),
    injuries=("injuries", "sum"),
    unresolved=("resolved", lambda s: (s != 1).sum()),
    incident_types=("incident_type", lambda s: ", ".join(sorted(set(s.dropna().astype(str)))))
).reset_index()
comp = complaints.groupby("location_id").agg(
    complaint_count=("complaint_id", "count"),
    high_priority_complaints=("priority_reported", lambda s: s.astype(str).str.strip().str.lower().isin(["high", "urgent", "critical"]).sum()),
    complaint_categories=("category", lambda s: ", ".join(sorted(set(s.dropna().astype(str)))))
).reset_index()
ranked = locations.merge(inc, on="location_id", how="left").merge(comp, on="location_id", how="left")
ranked = ranked.merge(ml_risk, on="location_id", how="left")
ranked["ml_severity_risk"] = ranked["ml_severity_risk"].fillna(0.0)
for c in ["incident_count", "high_critical", "injuries", "unresolved", "complaint_count", "high_priority_complaints"]:
    ranked[c] = ranked[c].fillna(0)

# Transparent deterministic baseline. Six listed signals total 94%; the final 6% is a
# clearly disclosed contextual adjustment derived from supplied context fields.
ranked["context_score"] = (
    pd.to_numeric(ranked["near_school"], errors="coerce").fillna(0).clip(0, 1) * 0.35 +
    pd.to_numeric(ranked["near_hospital"], errors="coerce").fillna(0).clip(0, 1) * 0.35 +
    ranked["pedestrian_activity"].astype(str).str.strip().str.lower().map({"low": 0.0, "medium": 0.5, "high": 1.0}).fillna(0.0) * 0.30
)
ranked["priority_score"] = 100 * (
    .22 * norm(ranked["incident_count"]) +
    .22 * norm(ranked["high_critical"]) +
    .18 * norm(ranked["injuries"]) +
    .16 * norm(ranked["complaint_count"]) +
    .10 * norm(ranked["unresolved"]) +
    .06 * norm(ranked["high_priority_complaints"]) +
    .06 * ranked["ml_severity_risk"]
)
ranked["context_flags"] = ranked.apply(lambda r: ", ".join(
    (["Near school"] if str(r.get("near_school", 0)).strip() in ["1", "1.0", "True", "true"] else []) +
    (["Near hospital"] if str(r.get("near_hospital", 0)).strip() in ["1", "1.0", "True", "true"] else []) +
    ([f"Pedestrian activity: {r.get('pedestrian_activity')}"] if pd.notna(r.get("pedestrian_activity")) else [])
) or "No context flags", axis=1)
ranked = ranked.sort_values("priority_score", ascending=False).reset_index(drop=True)
ranked.insert(0, "rank", np.arange(1, len(ranked) + 1))

st.markdown("""
<style>
.block-container {padding-top:1.3rem;padding-bottom:2rem}
.hero {padding:1.3rem 1.5rem;border-radius:15px;background:linear-gradient(120deg,#0b1f3a,#145374);color:white;margin-bottom:1rem}
.hero h1 {color:white;margin:0;font-size:2.1rem}.hero p {color:#e3eef6;margin:.35rem 0 0 0}
</style>
<div class="hero"><h1>🏙️ CivicPriority AI</h1><p>Where should a city fix first? · Explainable civic issue triage · Team Veeram</p></div>
""", unsafe_allow_html=True)
st.warning("The supplied dataset is synthetic and educational. A Random Forest model is trained to predict incident severity; its predicted High/Critical risk contributes 6% to the location ranking. This is a prototype, not a validated real-world risk assessment. Human review is required.")

with st.sidebar:
    st.header("Explore priorities")
    zones = ["All zones"] + sorted(ranked["zone"].dropna().astype(str).unique().tolist())
    zone = st.selectbox("Zone", zones)
    sev = st.selectbox("Severity signal", ["All locations", "At least one High/Critical incident", "No High/Critical incidents"])
    min_inc = st.slider("Minimum incident count", 0, int(ranked["incident_count"].max()), 0)
    search = st.text_input("Search location ID", placeholder="e.g. L0001")
    st.divider()
    st.caption("Score weights")
    st.caption("Frequency 22% · High/Critical 22% · Injuries 18%")
    st.caption("Complaints 16% · Unresolved 10% · High-priority complaints 6% · ML severity risk 6%")

filtered = ranked.copy()
if zone != "All zones": filtered = filtered[filtered["zone"].astype(str) == zone]
if sev == "At least one High/Critical incident": filtered = filtered[filtered["high_critical"] > 0]
elif sev == "No High/Critical incidents": filtered = filtered[filtered["high_critical"] == 0]
filtered = filtered[filtered["incident_count"] >= min_inc]
if search.strip(): filtered = filtered[filtered["location_id"].astype(str).str.contains(search.strip(), case=False, na=False)]

resolved_pct = (incidents["resolved"] == 1).mean() * 100
c1,c2,c3,c4 = st.columns(4)
c1.metric("Locations", f"{len(locations):,}")
c2.metric("Incidents", f"{len(incidents):,}")
c3.metric("Public complaints", f"{len(complaints):,}")
c4.metric("Incidents marked resolved", f"{resolved_pct:.1f}%")

leader, details, method, ml_tab = st.tabs(["📊 Priority leaderboard", "🔎 Location details", "🧾 Data & methodology", "🤖 ML model"])
with leader:
    st.subheader("Ranked locations")
    st.caption(f"Showing {len(filtered):,} of {len(ranked):,} locations. Scores compare locations within this dataset; they are not probabilities.")
    cols = ["rank","location_id","zone","priority_score","incident_count","high_critical","injuries","complaint_count","unresolved","context_flags"]
    table = filtered[cols].copy()
    table["priority_score"] = table["priority_score"].round(1)
    table = table.rename(columns={"rank":"Rank","location_id":"Location ID","zone":"Zone","priority_score":"Priority score","incident_count":"Incidents","high_critical":"High/Critical","injuries":"Injuries","complaint_count":"Complaints","unresolved":"Unresolved incidents","context_flags":"Context flags"})
    st.dataframe(table, use_container_width=True, hide_index=True, height=440)
    if not filtered.empty:
        st.subheader("Top 12 filtered locations")
        st.bar_chart(filtered.head(12).set_index("location_id")["priority_score"])
    st.download_button("⬇️ Download filtered ranking CSV", filtered.to_csv(index=False).encode("utf-8"), "civicpriority_rankings.csv", "text/csv")
with details:
    st.subheader("Inspect a location")
    opts = filtered["location_id"].astype(str).tolist()
    if not opts:
        st.info("No locations match these filters. Change the filters in the sidebar.")
    else:
        chosen = st.selectbox("Choose location", opts)
        row = ranked[ranked["location_id"].astype(str) == chosen].iloc[0]
        a,b,c,d = st.columns(4)
        a.metric("Overall rank", f"#{int(row['rank'])}")
        b.metric("Priority score", f"{row['priority_score']:.1f}/100")
        c.metric("Incidents", int(row["incident_count"]))
        d.metric("Complaints", int(row["complaint_count"]))
        left,right = st.columns(2)
        with left:
            st.markdown("**Score contributing signals**")
            st.write(f"- Incident reports: **{int(row['incident_count'])}**")
            st.write(f"- High/Critical incidents: **{int(row['high_critical'])}**")
            st.write(f"- Recorded injuries: **{int(row['injuries'])}**")
            st.write(f"- Public complaints: **{int(row['complaint_count'])}**")
            st.write(f"- Unresolved incidents: **{int(row['unresolved'])}**")
            st.write(f"- High-priority complaints: **{int(row['high_priority_complaints'])}**")
        with right:
            st.markdown("**Context for human review**")
            st.write(f"- Zone: {row.get('zone','Unknown')}")
            st.write(f"- Road type: {row.get('road_type','Unknown')}")
            st.write(f"- Road condition: {row.get('road_condition','Unknown')}")
            st.write(f"- Near school: {'Yes' if str(row.get('near_school',0)) in ['1','1.0'] else 'No'}")
            st.write(f"- Near hospital: {'Yes' if str(row.get('near_hospital',0)) in ['1','1.0'] else 'No'}")
            st.write(f"- Pedestrian activity: {row.get('pedestrian_activity','Unknown')}")
            st.write(f"- Coordinates: {row.get('latitude',np.nan):.5f}, {row.get('longitude',np.nan):.5f}")
        with st.expander("Incident records at this location"):
            st.dataframe(incidents[incidents["location_id"].astype(str)==chosen], use_container_width=True, hide_index=True)
        with st.expander("Public complaints at this location"):
            st.dataframe(complaints[complaints["location_id"].astype(str)==chosen], use_container_width=True, hide_index=True)
with method:
    st.subheader("Dataset used")
    st.write("- `locations.csv`: 1,000 location records")
    st.write("- `incidents.csv`: 10,000 incident records")
    st.write("- `public_complaints.csv`: 8,000 complaint records")
    st.write("Tables are linked by `location_id`. Location-level incident and complaint signals are aggregated before ranking.")
    st.subheader("Transparent baseline formula")
    st.code("Score = 100 × (0.22×frequency + 0.22×high/critical + 0.18×injuries + 0.16×complaints + 0.10×unresolved + 0.06×high-priority complaints + 0.06×ML severity risk)", language="text")
    st.write("Each of the six operational signals before ML risk is min-max normalised across locations. ML severity risk is the average model-predicted probability of High/Critical severity among incidents at that location. School, hospital and pedestrian context remain visible for human review, not directly added to the score.")
    st.write("This is a hybrid prototype: a Random Forest classifier predicts incident severity, and a transparent weighted score ranks locations. The dataset contains severity labels but no ground-truth location-priority labels, so the ranking itself has not been validated as a prediction of the “correct” repair order.")
    st.subheader("Limitations and safeguards")
    st.write("- All records and coordinates are synthetic; do not interpret the results as real-city facts.")
    st.write("- Weights are proposed design choices and should be reviewed with civic experts.")
    st.write("- Scores support triage and do not replace emergency procedures, field inspection, or official judgement.")


with ml_tab:
    st.subheader("Random Forest: incident severity prediction")
    st.write("The model learns from incident type, reporter type, location characteristics, and report time to predict Low, Medium, High, or Critical severity.")
    st.caption("Training/test split: 75% / 25%, stratified, random_state=42. Features exclude injuries, resolution status, and resolution time to reduce information leakage.")
    m1, m2, m3 = st.columns(3)
    m1.metric("Held-out test accuracy", f"{model_accuracy:.1%}")
    m2.metric("Macro F1 score", f"{model_macro_f1:.3f}")
    m3.metric("Test incidents", f"{test_rows:,}")
    st.info("These are results on a held-out split of synthetic educational data. They are not evidence of performance on real city incidents.")
    st.subheader("Per-class test results")
    rep_df = pd.DataFrame(model_report).T
    keep = [c for c in ["precision", "recall", "f1-score", "support"] if c in rep_df.columns]
    st.dataframe(rep_df.loc[[c for c in model_classes if c in rep_df.index], keep].round(3), use_container_width=True)
    st.subheader("Confusion matrix")
    cm_df = pd.DataFrame(model_matrix, index=[f"Actual {c}" for c in model_classes],
                         columns=[f"Predicted {c}" for c in model_classes])
    st.dataframe(cm_df, use_container_width=True)
    st.subheader("How ML affects the ranking")
    st.write("For each incident, the model estimates the probability that its severity is High or Critical. We average that probability for each location. This ML risk signal contributes 6% of the location score; the remaining 94% comes from the disclosed incident and complaint indicators.")
    st.write("The model predicts incident severity, not whether a road repair will succeed or which location is objectively the most urgent. The ranking is a decision-support prototype and needs validation with civic experts.")
    st.download_button("⬇️ Download test-set class metrics", pd.DataFrame(model_report).T.to_csv().encode("utf-8"), "civicpriority_ml_classification_report.csv", "text/csv")

st.caption("CivicPriority AI · Datathon 2026 Round 1 · Team Veeram")
