"""Basic data-integrity test cases for CivicPriority AI.
Run from project folder: python test_cases.py
"""
from pathlib import Path
import pandas as pd
BASE=Path(__file__).parent; DATA=BASE/'data'
checks=[]
def check(name, condition, detail=''):
    ok=bool(condition); checks.append(ok)
    print(('PASS' if ok else 'FAIL')+' - '+name+((': '+detail) if detail else ''))
try:
    locations=pd.read_csv(DATA/'locations.csv'); incidents=pd.read_csv(DATA/'incidents.csv'); complaints=pd.read_csv(DATA/'public_complaints.csv')
    check('locations file loads',len(locations)>0)
    check('incidents file loads',len(incidents)>0)
    check('complaints file loads',len(complaints)>0)
    check('location_id exists in all files',all('location_id' in x.columns for x in [locations,incidents,complaints]))
    check('location IDs unique in locations',locations['location_id'].is_unique)
    check('incident severity has expected labels',set(incidents['severity'].dropna().astype(str).str.strip().str.title()).issubset({'Low','Medium','High','Critical'}))
    check('incident IDs unique',incidents['incident_id'].is_unique)
    check('complaint IDs unique',complaints['complaint_id'].is_unique)
    check('incident timestamps parse',pd.to_datetime(incidents['timestamp'],errors='coerce').notna().mean()>.95)
    check('joins do not explode incident row count',len(incidents.merge(locations,on='location_id',how='left'))==len(incidents))
    unknown_inc=set(incidents['location_id'].dropna())-set(locations['location_id'].dropna())
    unknown_comp=set(complaints['location_id'].dropna())-set(locations['location_id'].dropna())
    check('all incident locations match',not unknown_inc,f'{len(unknown_inc)} unmatched IDs')
    check('all complaint locations match',not unknown_comp,f'{len(unknown_comp)} unmatched IDs')
except Exception as e:
    print('FAIL - files load / schema:',repr(e)); checks.append(False)
print(f'\n{sum(checks)}/{len(checks)} checks passed.')
raise SystemExit(0 if all(checks) else 1)
