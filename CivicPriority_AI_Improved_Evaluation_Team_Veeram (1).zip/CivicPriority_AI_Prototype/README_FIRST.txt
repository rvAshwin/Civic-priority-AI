CIVICPRIORITY AI — TEAM VEERAM
Working local dashboard prototype for Windows

HOW TO RUN
1. Extract this ZIP into a normal folder, e.g. Desktop\CivicPriority_AI_Prototype.
2. Open the extracted folder in File Explorer.
3. Click the folder address bar, type cmd, and press Enter.
4. Run these commands one at a time:

   py -m pip install -r requirements.txt
   py -m streamlit run app.py

5. Your browser should open. If not, copy the Local URL printed in the terminal (usually http://localhost:8501) into Chrome.
6. Keep the terminal open while demonstrating the app. Press Ctrl+C in the terminal to stop it.

WHAT IT DOES
- Loads the provided locations, incidents, and public complaints CSVs.
- Joins records by location_id and aggregates location-level signals.
- Calculates a transparent, weighted priority score and ranks locations.
- Lets you filter by zone/severity, search a location, inspect contributing factors,
  view underlying records, and download the filtered ranking as CSV.

IMPORTANT HONESTY NOTES
- The dataset is synthetic and educational.
- This is a deterministic scoring baseline, NOT a trained ML model.
- No ground-truth labels or validated prediction accuracy are available.
- Scores are comparative within this dataset and require human review.


ML VERSION NOTES
- This version trains a Random Forest classifier from scratch on the supplied incidents.csv labels.
- Target: incident severity (Low, Medium, High, Critical).
- Inputs: incident type, reporter type, location context, report hour/month.
- Excluded from input features: injuries, resolved status, and resolution time, to avoid using post-report outcomes.
- Fixed stratified split: 75% train / 25% test (random_state=42).
- On this dataset version, held-out accuracy was about 35.4% and macro F1 about 0.241 in a local test. This is weak performance; show it honestly and do not claim high accuracy.
- The model is experimental. The location ranking uses its average predicted High/Critical probability for 6% of the score. There are no ground-truth location-priority labels, so the final location ranking is not a validated prediction.
- All supplied data is synthetic and educational. Do not present the results as real city outcomes.


IMPROVED EVALUATION UTILITIES
-----------------------------
Run data-integrity checks:
  python test_cases.py
Compare models fairly on the same stratified holdout split:
  python model_benchmark.py

Metrics include accuracy, balanced accuracy, macro-F1, and per-class precision/recall.
No code can honestly guarantee 99% accuracy from this dataset. The labels are synthetic,
and the available features may not contain enough information to predict severity. Do not
change test labels or report training accuracy as test accuracy. Use the held-out results.
